<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FITNESS GALLERY</title>
    <link href="css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Open+Sans:wght@300;400;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/adaa5eca50.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class ="gallery_header">
        <header class="header">
            <div class="containerm1 flex-container">
                <div class="logo">
                    <img src="images/red_drop.png" width="32" alt="Red drop"><span>FITNESS</span>
                </div>
                <nav class="main-nav">
                    <ul class="flex-container">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="index.php#how">HOW IT WORKS</a></li>
                        <li><a href="gallery.php">GALLERY</a></li>
                        <li><a href="index.php#about">ABOUT</a></li>
                        <li><a href="index.php#contact">CONTACT</a></li>
                    </ul>
                </nav>
                <nav class="mobile-nav">
                    <ul id="mobile" class="flex-container"> 
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="index.php#how">HOW IT WORKS</a></li>
                        <li><a href="gallery.php">GALLERY</a></li>
                        <li><a href="index.php#about">ABOUT</a></li>
                        <li><a href="index.php#contact">CONTACT</a></li>
                    </ul>
                    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                    <i class="fa fa-bars"></i>
                    </a>
                </nav>
            </div>
        </header>
    </div>
    <div class="gallery_info">
         <h2>The video gallery of work-outs by our members</h2>
    </div>
    <div class="gallery_content">
        <div class="vid1 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=oAPCPjnU1wA"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid2 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=ml6cT4AZdqI"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid3 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=1skBf6h2ksI"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid4 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=Og_f0_QO_Ko"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid5 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=MiJ2OtqhJGw"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid6 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=zr08J6wB53Y"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid7 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=UBMk30rjy0o"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid8 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=fcN37TxBE_s"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid9 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=MrV4vCotio0"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid10 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=-irx3_FA2nU"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid11 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=YdB1HMCldJY"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
        <div class="vid12 flex-container">
            <a data-fancybox href="https://www.youtube.com/watch?v=go8rGQro3dY"><img src="images/play.gif" width="70" alt="Play button">
            </a>
        </div>
    </div>
    <footer class="footer">
        <?php
            echo '&copy; ' . date("Y") . ' Fitness community';
        ?>
    </footer>
    <script src="scripts/jquery.min.js"></script>
    <script src="scripts/jquery.fancybox.min.js"></script>
    <script src="scripts/custom.js"></script> 
</body>
</html>