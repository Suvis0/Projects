<?php
    require __DIR__ . '/src/app.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FITNESS</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Open+Sans:wght@300;400;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/adaa5eca50.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container1">
        <header class="header">
            <div class="containerm1 flex-container">
                <div class="logo">
                    <img src="images/red_drop.png" width="32" alt="Red drop"><span>FITNESS</span>
                </div>
                <nav class="main-nav">
                    <ul class="flex-container">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="index.php#how">HOW IT WORKS</a></li>
                        <li><a href="gallery.php">GALLERY</a></li>
                        <li><a href="index.php#about">ABOUT</a></li>
                        <li><a href="index.php#contact">CONTACT</a></li>
                    </ul>
                </nav>
                <nav class="mobile-nav">
                    <ul id="mobile" class="flex-container"> 
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="index.php#how">HOW IT WORKS</a></li>
                        <li><a href="gallery.php">GALLERY</a></li>
                        <li><a href="index.php#about">ABOUT</a></li>
                        <li><a href="index.php#contact">CONTACT</a></li>
                    </ul>
                    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                    <i class="fa fa-bars"></i>
                    </a>
                </nav>
            </div>
        </header>
        <div class="fitness_can">
            <span>FITNESS IN A CAN<span style="color:#a2ca28">/</span></span>
        </div>
        <div class="yes">
            <span>YES YOU CAN<span style="color:#fd634e">/</span></span>
        </div>
    </div>
    <a name = 'how'></a>
    <div class="container2">
        <div class="resources">
            <img src="images/resources.png" height="45" alt="Suitcase">
            <h2>Resources</h2>
            <p>We are a worldwide fitness community and our members are the ones who share their knowledge and experience in order to fulfill our main goal - get fit &amp; healthy.</p>
        </div>
        <div class="training">
            <img src="images/training.png" height="45" alt="Measurement circle">
            <h2>Training &amp; Funding</h2>
            <p>We share the material of effective training so that anyone could learn good methods of working out and apply it to themselves. Some investors help us to grow by funding us regularly.</p>
        </div>
        <div class="connect">
            <img src="images/connect.png" height="45" alt="cloud">
            <h2>Connect</h2>
            <p>Joining our community will help You to become guru of fitness. And as soon as You become one - You could help others to reach their goals.</p>
        </div>
        <div class="communicate">
            <img src="images/communicate.png" height="45" alt="chat logo">
            <h2>Communicate</h2>
            <p>Communication is essential part of our improvement. Sharing the experience and giving advices to each other is the way our community thrives. We keep in touch on social media and by participating in virtual meetings.</p>
        </div>
        <div class="its">
            <h3>IT'S ALL ABOUT</h3>
            <h2>FITNESS FIRST</h2>
            <img src="images/grey_drop.png" alt="little grey drop">
            <p>Working out is vital in order to stay healthy and happy. This has to be a routine of some level depending on Your timetable and the desired result.</p>
        </div>
        <div class="woman">
        
        </div>
        <div class="watch">
        
        </div>
        <div class="love">
            <h3>LOVE YOUR</h3>
            <h2>BODY</h2>
            <img src="images/grey_drop.png" alt="little grey drop">
            <p>Think of your body as the vehicle to your dreams.  Honor it.  Respect it.  Fuel it. Become aware of what your body can do each day.  Remember it is the instrument of your life, not just an ornament.</p>
        </div>
    </div>
    <div class="container3">
        <div class="running">
        </div>
        <div class="beach">
        </div>
        <div class="track">
            <h3>TRACK YOUR</h3>
            <h2>LIFESTYLE</h2>
            <p>Tracking works because it makes you self-aware and therefore, accountable. By providing feedback and nudges, tracking helps you literally see your good and bad habits.</p>
        </div>
        <div class="summer">
            <h2>SUMMER OF FUN</h2>
            <p>If You have ever felt shy or embarassed at the beach by showing Your body to the world instead of just enjoying the moment, then the fact that You are putting efforts to improve Your fitness level must do the job and make You proud of Yourself.</p>
        </div>
        <div class="grapes">
        </div>
        <div class="fruits">
        </div>
        <div class="you">
            <h3>YOU HAVE TO</h3>
            <h2>GET INVOLVED IN YOURSELF</h2>
            <p>It’s so important to make sure you take good care of your body, mind, and soul every day, not just when you get sick. Learning how to eat right, reduce stress, exercise regularly, and take a time-out when you need it are touchstones of self-care and can help you stay healthy, happy, and resilient.</p>
        </div>
        <div class="improve">
            <h3>IMPROVE YOUR</h3>
            <h2>EATING HABITS</h2>
            <p>Eat the rainbow. Every fruit and vegetable has different colors based on the different minerals, vitamins, phytochemicals, and antioxidants it contains.</p>
        </div>
    </div>
    <div class="container4">
        <div class="launch">
            <h2>We launch leaders with big ideas</h2>
            <p>We have many success stories of how turning the lifestyle around contributed to building a successful career or even business.</p>
        </div>
    </div>
    <a name = 'about'></a>
    <div class="container5">
        <div class="about">
            <h3>About us</h3>
            <p>The idea of just a few people sharing their knowledge and experience of work-out tehniques grew into a global community within a decade. We have now members from different continents willing to spread the "virus" of a healthy lifestyle. Our old-timers create and share training videos and healthy eating plans. There is a great variety of choice for new members to start implementing the changes of lifestyle and the support in the process is what we are proud of.</p>
        </div>
        <a name ='contact'></a>
        <div class="contact">
            <h3>Contact us</h3>
            <p>You can contact us by sending us a message by filling the message box - just enter your name, email and anything that interests You in the "Your message" field. We are also available on Facebook, Twitter, Youtube and Linkedin so do not hesitate to follow us or text us there.</p>
        </div>
        <div class="touch">
            <h3>Stay in touch</h3>
                <nav class="social-nav">
                    <ul class="flex-container">
                        <li><a href="http://facebook.com"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="http://twitter.com"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="http://youtube.com"><i class="fab fa-youtube"></i></a></li>
                        <li><a href="http://linkedin.com"><i class="fab fa-linkedin-in"></i></a></li>
                    </ul>
                </nav>
        </div>
        <div class="direct_contact">
                <form class="contact-form" action="index.php" method="post">
                    <div class="input-row">
                        <input type="text" name="name" placeholder="Your Name*" required>
                        <input type="email" name="email" placeholder="Your Email*" required>
                    </div>
                    <textarea name="message" rows="6" placeholder="Your Message*" required></textarea>
                    <input class="btn" type="submit" name="submit">
                </form>
        </div>
    </div>
    <footer class="footer">
        <nav class="social-nav2">
            <ul class="flex-container">
                <li><a href="http://facebook.com"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="http://twitter.com"><i class="fab fa-twitter"></i></a></li>
                <li><a href="http://youtube.com"><i class="fab fa-youtube"></i></a></li>
                <li><a href="http://linkedin.com"><i class="fab fa-linkedin-in"></i></a></li>
            </ul>
        </nav>
        <?php
            echo '&copy; ' . date("Y") . ' Fitness community';
        ?>
    </footer>
    <script src="scripts/custom.js"></script> 
</body>
</html>